package CheckIn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CheckInApplicationTests {

	@Test
	void contextLoads() {
	}

}
